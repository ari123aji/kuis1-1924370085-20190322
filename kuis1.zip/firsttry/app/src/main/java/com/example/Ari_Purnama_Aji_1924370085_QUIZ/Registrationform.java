package com.example.Ari_Purnama_Aji_1924370085_QUIZ;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Registrationform extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrationform);
    }
}